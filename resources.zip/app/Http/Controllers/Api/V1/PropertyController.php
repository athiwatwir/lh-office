<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\PropertyIndexRequest;
use App\Http\Requests\Api\PropertySearchRequest;
use App\Http\Resources\Api\PropertyDetailResource;
use App\Http\Resources\Api\PropertyListResource;
use App\Models\Asset;
use App\Services\AssetViewService;
use App\Services\PropertyApiImageWarmer;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

class PropertyController extends Controller
{
    public function __construct(
        private readonly AssetViewService $assetViews,
        private readonly PropertyApiImageWarmer $imageWarmer,
    ) {}

    public function index(PropertyIndexRequest $request): AnonymousResourceCollection
    {
        $properties = Asset::query()
            ->active()
            ->with([
                'asset_type:id,name',
                'agent:id,name,code',
                'zone:id,name',
                'user:id,firstname,lastname,phone',
                'address:id,amphur',
                'asset_images' => fn($query) => $query
                    ->orderByRaw("CASE WHEN isdefault = 'Y' THEN 0 ELSE 1 END")
                    ->orderBy('seq')
                    ->limit(1)
                    ->with('image'),
            ])
            ->withCount('asset_images')
            ->when(
                $request->assetTypeId(),
                fn($query) => $query->where('asset_type_id', $request->assetTypeId()),
            )
            ->when(
                $request->agentId(),
                fn($query) => $query->where('agent_id', $request->agentId()),
            )
            ->when(
                $request->userId(),
                fn($query) => $query->where('user_id', $request->userId()),
            )
            ->when(
                $request->zoneId(),
                fn($query) => $query->where('zone_id', $request->zoneId()),
            )
            ->when(
                $request->isRecommendFilter() === true,
                fn($query) => $query->where('isrecommend', 'Y'),
            )
            ->when(
                $request->isRecommendFilter() === false,
                fn($query) => $query->where(fn($builder) => $builder
                    ->where('isrecommend', '!=', 'Y')
                    ->orWhereNull('isrecommend')),
            )
            ->latestFirst()
            ->paginate($request->perPage());

        $this->imageWarmer->warmListThumbnails($properties);

        return PropertyListResource::collection($properties);
    }

    public function show(string $property): PropertyDetailResource
    {
        $item = Asset::query()
            ->active()
            ->with([
                'asset_type:id,name',
                'agent:id,name,code,logo',
                'zone:id,name',
                'address',
                'user:id,firstname,lastname,phone,email,lineid,image_id',
                'user.image',
                'asset_images' => fn($query) => $query->orderBy('seq')->with('image'),
            ])
            ->findOrFail($property);

        $this->imageWarmer->warmDetailImages($item);

        return new PropertyDetailResource($item);
    }

    public function recordView(string $property): JsonResponse
    {
        $asset = Asset::query()
            ->active()
            ->findOrFail($property);

        $result = $this->assetViews->record($asset);

        return response()->json($result);
    }

    public function search(PropertySearchRequest $request): AnonymousResourceCollection
    {
        $properties = Asset::query()
            ->active()
            ->with([
                'asset_type:id,name',
                'agent:id,name,code',
                'zone:id,name',
                'user:id,firstname,lastname,phone',
                'address:id,amphur',
                'asset_images' => fn ($query) => $query
                    ->orderByRaw("CASE WHEN isdefault = 'Y' THEN 0 ELSE 1 END")
                    ->orderBy('seq')
                    ->limit(1)
                    ->with('image'),
            ])
            ->withCount('asset_images')
            ->when(
                $request->text(),
                fn ($query, $text) => $query->where(function ($builder) use ($text) {
                    $builder
                        ->where('code', 'like', "%{$text}%")
                        ->orWhere('name', 'like', "%{$text}%")
                        ->orWhereHas('address', fn ($addressQuery) => $addressQuery
                            ->where('address1', 'like', "%{$text}%"));
                }),
            )
            ->when(
                $request->assetTypeId(),
                fn ($query, $assetTypeId) => $query->where('asset_type_id', $assetTypeId),
            )
            ->when(
                $request->province(),
                fn ($query, $province) => $query->whereHas('address', fn ($addressQuery) => $addressQuery
                    ->where('province', 'like', "%{$province}%")),
            )
            ->when(
                $request->district(),
                fn ($query, $district) => $query->whereHas('address', fn ($addressQuery) => $addressQuery
                    ->where('district', 'like', "%{$district}%")),
            )
            ->when(
                $request->amphur(),
                fn ($query, $amphur) => $query->whereHas('address', fn ($addressQuery) => $addressQuery
                    ->where('amphur', 'like', "%{$amphur}%")),
            )
            ->when(
                $request->priceMin() !== null,
                fn ($query) => $query->where('price_amounnt', '>=', $request->priceMin()),
            )
            ->when(
                $request->priceMax() !== null,
                fn ($query) => $query->where('price_amounnt', '<=', $request->priceMax()),
            )
            ->latestFirst()
            ->paginate($request->perPage());

        $this->imageWarmer->warmListThumbnails($properties);

        return PropertyListResource::collection($properties);
    }
}
